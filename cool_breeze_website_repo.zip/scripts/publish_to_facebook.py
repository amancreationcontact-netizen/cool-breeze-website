#!/usr/bin/env python3
"""
Cool Breeze Air Pvt. Ltd. - Automated Facebook Publisher
Agency: A-man Creation
Executes daily scheduled photo & caption uploads to Facebook via Graph API.
"""

import os
import sys
import json
import requests

def main():
    page_id = os.environ.get("FACEBOOK_PAGE_ID")
    access_token = os.environ.get("FACEBOOK_ACCESS_TOKEN")

    if not page_id or not access_token:
        config_path = os.path.join(os.path.dirname(__file__), "..", "config", "facebook_credentials.json")
        if os.path.exists(config_path):
            with open(config_path, "r", encoding="utf-8") as f:
                creds = json.load(f)
                page_id = creds["facebook"].get("page_id")
                access_token = creds["facebook"].get("access_token")

    if not page_id or not access_token:
        print("ERROR: Missing FACEBOOK_PAGE_ID or FACEBOOK_ACCESS_TOKEN.")
        sys.exit(1)

    queue_file = os.path.join(os.path.dirname(__file__), "..", "data", "current_post.json")
    if not os.path.exists(queue_file):
        print(f"ERROR: No pending post found at {queue_file}")
        sys.exit(1)

    with open(queue_file, "r", encoding="utf-8") as f:
        post_data = json.load(f)

    caption = post_data.get("caption")
    image_path = post_data.get("image_path")

    url = f"https://graph.facebook.com/v20.0/{page_id}/photos"
    
    if image_path and os.path.exists(image_path):
        print(f"Publishing image {image_path} to Facebook Page {page_id}...")
        with open(image_path, "rb") as img:
            files = {"source": img}
            data = {
                "message": caption,
                "access_token": access_token
            }
            response = requests.post(url, files=files, data=data)
    elif post_data.get("image_url"):
        print(f"Publishing image from CDN URL to Facebook Page {page_id}...")
        data = {
            "url": post_data["image_url"],
            "message": caption,
            "access_token": access_token
        }
        response = requests.post(url, data=data)
    else:
        print(f"Publishing text feed post to Facebook Page {page_id}...")
        feed_url = f"https://graph.facebook.com/v20.0/{page_id}/feed"
        data = {
            "message": caption,
            "access_token": access_token
        }
        response = requests.post(feed_url, data=data)

    result = response.json()
    if response.status_code == 200 and ("id" in result or "post_id" in result):
        post_id = result.get("post_id") or result.get("id")
        print(f"SUCCESS: Post published successfully! Post ID: {post_id}")
    else:
        print(f"FAILED to publish. Response: {result}")
        sys.exit(1)

if __name__ == "__main__":
    main()
